package kursiyer;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Kursiyer Adını Giriniz:");
        String ad = scan.nextLine();

        System.out.println("Kursiyer Yaşını Giriniz:");
        int yas = scan.nextInt();

        System.out.println("Kurs Ücretini Giriniz:");
        double ucret = scan.nextDouble();

        System.out.println("Kursiyer Türünü Seçiniz:");
        System.out.println("1- İlkokul Öğrencisi");
        System.out.println("2- Lise Öğrencisi");
        System.out.println("3- Yetişkin Öğrenci");
        int secim = scan.nextInt();

        if (secim == 1) {
            IlkokulOgrencisi ilkokul = new IlkokulOgrencisi(ad, yas, ucret);
            System.out.println(ilkokul.kursiyerBilgileri());
        }
        else if (secim == 2) {
            LiseOgrencisi lise = new LiseOgrencisi(ad, yas, ucret);
            System.out.println(lise.kursiyerBilgileri());
        }
        else if (secim == 3) {
            YetiskinOgrenci yetiskin = new YetiskinOgrenci(ad, yas, ucret);
            System.out.println(yetiskin.kursiyerBilgileri());
        }
        else {
            System.out.println("Hatalı seçim yaptınız!");
        }
    }
}