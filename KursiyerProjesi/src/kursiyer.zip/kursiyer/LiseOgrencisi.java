package kursiyer;

public class LiseOgrencisi extends Kursiyer {

    LiseOgrencisi(String ad, int yas, double kursUcreti) {
        this.ad = ad;
        this.yas = yas;
        this.kursUcreti = kursUcreti;
        kursAdi = "Akademik Destek";
        egitimSeviyesi = "Lise";
        indirimOrani = 0.3;
    }
}