package kursiyer;

public class IlkokulOgrencisi extends Kursiyer {

    IlkokulOgrencisi(String ad, int yas, double kursUcreti) {
        this.ad = ad;
        this.yas = yas;
        this.kursUcreti = kursUcreti;
        kursAdi = "Temel Eğitim";
        egitimSeviyesi = "İlkokul";
        indirimOrani = 0.5;
    }
}
