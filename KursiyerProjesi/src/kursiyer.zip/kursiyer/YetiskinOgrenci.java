package kursiyer;

public class YetiskinOgrenci extends Kursiyer {

    YetiskinOgrenci(String ad, int yas, double kursUcreti) {
        this.ad = ad;
        this.yas = yas;
        this.kursUcreti = kursUcreti;
        kursAdi = "Mesleki Gelişim";
        egitimSeviyesi = "Yetişkin";
        indirimOrani = 0.1;
    }
}