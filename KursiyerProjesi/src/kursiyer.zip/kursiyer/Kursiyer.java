package kursiyer;

public class Kursiyer {
    String ad, kursAdi, egitimSeviyesi;
    int yas;
    double kursUcreti, indirimOrani;

    double odenecekTutar() {
        return kursUcreti - (kursUcreti * indirimOrani);
    }

    String kursiyerBilgileri() {
        return "Ad: " + ad + ", Yaş: " + yas + ", Seviye: " + egitimSeviyesi
             + ", Kurs: " + kursAdi + ", Ücret: " + kursUcreti
             + ", İndirim: %" + (indirimOrani * 100)
             + ", Ödenecek Tutar: " + odenecekTutar();
    }
}